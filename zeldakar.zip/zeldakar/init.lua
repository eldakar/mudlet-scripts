eld = eld or {}
return {
    "guardhelper",
    "showhiddencharacters"
}
